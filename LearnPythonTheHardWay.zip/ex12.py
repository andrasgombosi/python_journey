age = raw_input("How old are you? ")
height = raw_input("How tall? ")
weight = raw_input("How much do you weight")


print ("So you are %r old, %r tall and %r heavy") % (age,height,weight)
