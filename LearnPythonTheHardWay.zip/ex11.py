print "Age?",
age = raw_input(":")

print "Height?",
height = raw_input()

print "Weight?",
weight = raw_input()

print "Answers, %s and %s and  %s " % (age, height,weight)
