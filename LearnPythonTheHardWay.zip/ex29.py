people = 20
cats = 30
dogs = 15



if people < cats:
    print "Too many cats"

if cats < people:
    print "More people than cats"




dogs+= 5


if people >= dogs:
    print "People are greated than or equal to dogs"

if people <= dogs:
    print "People are less than or equal to dogs"

if people == dogs:
    print "people are dogs"
