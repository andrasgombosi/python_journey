print "Hens", 25+30/6
print "Roosters", 100.0-25.0*3%4

# evaluates this real time, writes False / True
print 3+2 < 5-7

#computes, writes end resuls
print 3+2
print 5-7

# comma separates text from computations
print "is it greater?", 5>-2
print "Is it greater or equal?", 5>=2
print "Is it less or equal?", 5<=2



print "Is it less or equal?", 5<=2 , "asd "

print 5/7
print 5.0/7.0


print 3%4


print 25 % 9
