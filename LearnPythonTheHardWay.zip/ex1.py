print "Hello World"
print "Hello Again"
print "tupe"
print "that"
print 'Yay! Printing.'
print "I'd much rather 'not'."
#print 'I said "do" not touch this.'
