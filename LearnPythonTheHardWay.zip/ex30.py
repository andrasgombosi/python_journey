people =30
cars =30
trucks =30


if cars > trucks:
    print "We should take the cars"
elif cars < people:
    print "More people than cars"
else:
    print "We cant decide"
