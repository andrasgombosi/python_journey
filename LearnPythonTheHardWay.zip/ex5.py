name = "Andy"
age = 36
height = 74
weight = 180

height_cm = height * 2.4


print "My name is %s" % name
print " tall %d" % height_cm
print " name is %s, again, %s" % (name, name)
print "my age is %d, double that and you get %d" % (age, age+age)
